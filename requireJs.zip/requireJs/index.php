<?php
?>
<!DOCTYPE html>
<html>
   <head>
      <title>requireJs learn</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
      <script id="requireCfg" type="text/javascript" src="http://localhost/webLearn/requireJs/views/app/js/lib/require.js" baseUrl="/webLearn/requireJs/views/app/js" 
        data-main="/webLearn/requireJs/views/app/js/AppMain.js?time=<?php echo time();?>"></script>
   </head>
   <body>
        <h1>test requirejs module!</h1>
   </body>
</html>