/*
define(function(){
    require.config({
        paths: {

        },
        shim:{

        },
        urlArgs: "time=" + (new Date()).getTime()
    })
})
*/
define(function(){
    require.config({
        paths: {
            "BaseClass" : './util/BaseClass',
            "loginPage" : './page/page/login',
            "page1" : './page/page/page1',
            "indexdb" : './util/indexdb',
            "jquery" : './lib/jquery'
        },
        shim:{

        },
        urlArgs: "time=" + (new Date()).getTime()
    })
})