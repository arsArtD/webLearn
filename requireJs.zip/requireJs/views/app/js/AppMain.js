var base = window?(document.getElementById('requireCfg').getAttribute('baseUrl')||'../js'):'../js';
//配置require
require.config({
    baseUrl: base || 'js'
});

//加载requirejs的配置文件
require(['requirecfg'],function(){
    require(["page1",
        "loginPage",
        "BaseClass",
        "indexdb",
    ],function(
        page1,
        loginPage,
        BaseClass,
        indexdb
    ){
        new loginPage();
        new page1();
        var db = new indexdb();
        console.log(db);
    })
});
