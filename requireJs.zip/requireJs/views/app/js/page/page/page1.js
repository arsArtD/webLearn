define([
    'BaseClass'
],function(
    BaseClass
){
    var page1 = BaseClass.extend({
        init: function() {
            var _this = this;
            console.log('page1 init');
        }
    });
    
    return page1;
})