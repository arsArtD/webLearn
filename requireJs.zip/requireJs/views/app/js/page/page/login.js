define([
    'BaseClass'
],function(
    BaseClass
){
    var loginPage = BaseClass.extend({
        init: function() {
            var _this = this;
            console.log('loginPage init');
        }
    });
    
    return loginPage;
})