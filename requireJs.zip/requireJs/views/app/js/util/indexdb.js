define(["jquery"], function (
    $
) {
    'use strict'
    // body
    var indexdb = BaseClass.extend({
        init: function (opts) {
            var _this = this;
            _this.version = 1.0;
            _this.opts = {
                version: new Date().getTime(),
                //version: '1.0.0',
                dbname: 'indexdb',
                debug: true
            };
            $.extend({}, _this.opts, opts);
            _this.dbname = _this.opts.dbname;
            _this.version = _this.opts.version;
            _this.db = null;
            _this._createdb(_this.dbname, _this.version);
        },
        _createdb: function (dbname, dbversion) {
            var _this = this;
            var dtd = $.Deferred();
            var dbConnect = window.indexedDB.open(dbname, dbversion);
            dbConnect.onsuccess = function (event) {
                //save the opened db
                _this.db = event.target.result;
                dtd.resolve(event.target.result);
            };
            dbConnect.onerror = function (event) {
                _showlog(event.target.error.message, 'error');
                dtd.reject(event.target.error);
            };
            dbConnect.onupgradeneeded = function (event) {
                _this._showlog('DB version changed to '+dbversion);
                var db= event.target.result;
                if(!db.objectStoreNames.contains('msg')){
                    db.createObjectStore('msg',{keyPath:"id"});
                }
                dtd.resolve(event);
            };
            return dtd.promise();
        },
        deletedb: function (dbname) {
            var _this = this;
            var dtd = $.Deferred();
            var dbConnect = window.indexedDB.deleteDatabase(dbname);
            dbConnect.onsuccess = function (event) {
                dtd.resolve();
            };
            dbConnect.onerror = function (event) {
                _showlog(event.target.error.message, 'error');
                dtd.reject(event.target.error);
            };
            return dtd.promise();
        },
        _showlog: function (msg, level = 'info') {
            var _this = this;
            if (typeof window.console != 'undefined' && _this.opts.debug) {
                switch (level) {
                    case "error":
                        console.error('indexdb module:');
                        console.error(msg);
                        break;
                    case "info":
                        console.log('indexdb module:');
                        console.log(msg);
                        break;
                }
            }
        }
    });
    return indexdb;
});
